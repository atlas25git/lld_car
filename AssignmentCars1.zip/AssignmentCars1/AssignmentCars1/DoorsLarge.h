#pragma once
#include "Doors.h"

class DoorsLarge : protected Doors
{
public:

	DoorsLarge();

	void SetDoorsLarge(int n);
	int GetDoorCount();
	string GetDoorSize();

	~DoorsLarge();

};