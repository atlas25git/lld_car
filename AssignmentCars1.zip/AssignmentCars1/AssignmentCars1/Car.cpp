#include "Car.h"

Car::Car() {
	
	DL.SetDoorsLarge(0);
	Type = "Car";

#ifdef debugON
	cout << "In constructor Car\n";
#endif
}

void Car::GetDoorsCount() {

	int total = DL.GetDoorCount() + DS.GetDoorCount();


#ifdef debugON
	cout << "In  GetDoorsCount Class: Car\n";
#endif
}

void Car::GetDoorsSize() {
	
	if (DL.GetDoorCount())
		cout << "Door Size is Large\n";
	else if (DS.GetDoorCount())
		cout << "Door Size is Small\n";

#ifdef debugON
	cout << "In GetDoorsSize of Class: Car\n";
#endif
}

Car::~Car() {
#ifdef debugON
	cout << "In destructor Car\n";
#endif
}