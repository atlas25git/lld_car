#pragma once
#include "DoorsLarge.h"
#include "DoorsSmall.h"
#include <iostream>
#include<fstream>
#include<istream>
#include<stdio.h>
#include<conio.h>
#include <vector>
#include<string>
#include "Debug.h"

class Car {

protected:
	DoorsLarge DL;
	DoorsSmall DS;
	string Type;

public:
	Car();

	virtual void GetDoorsCount();
	virtual void GetDoorsSize();

	virtual ~Car();

};