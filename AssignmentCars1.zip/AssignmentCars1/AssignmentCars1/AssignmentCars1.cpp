#include <iostream>
#include<fstream>
#include<istream>
#include<stdio.h>
#include<conio.h>
#include <vector>
#include<string>

//Change the macro's value in Debug.h file to alter debugging behavior
#include "Debug.h"

#include "Car.h"
#include "Nano.h"
#include "Swift.h"
#include "Tron.h"
#include "Doors.h"
#include "DoorsLarge.h"
#include "DoorsSmall.h"


using namespace std;

int main()
{	
	//freopen("output.txt", "w", stdout);
	//Tasks:
	//1. Define Classes
	//2. Write Getters for door count and size

	//3. Instantiate a Nano dynamically
	cout << "\n 3. Instantiating NANO dynamically on HEAP:\n";
	Car* car2 = new Nano();
	car2->GetDoorsCount();
	car2->GetDoorsSize();

	//4. Instantiate Swift and Tron as local variables on stack
	cout << "\n 4. Instantiating Swift as local variables on stack \n";
	Swift swift;


	cout << "\n 4.Instantiating Tron as local variables on stack \n";
	Tron tron;

	//5. Print door count for them.
	cout << "\n 5. Door count for Swift\n";
	swift.GetDoorsCount();

	cout << "\n 5. Door count for Tron\n";
	tron.GetDoorsCount();

	//6. Print door size them.
	cout << "\n 6. Door size for Swift\n";
	swift.GetDoorsSize();

	cout << "\n 6. Door size for Tron\n";
	tron.GetDoorsSize();


	//7. Function to iterate over a vector of dynamically created objects
	//   and iterate to print their properties;

	cout << "\n 7. Iterating a vector of items dynamically created: \n";

	Car* car1 = new Swift();
	// Car* car2 = new Nano();
	Car* car3 = new Tron();
	Car* car4 = new Swift();

	vector<Car*> cars = { car1,car2,car3,car4 };

	auto printSharedPTR = [](vector<Car*>& a) -> void
	{
#ifdef debugON
		cout << "In printSharedPTR\n";
#endif
		for (auto &x : a)
		{
			cout << " \n Details for ";
			x->GetDoorsCount();
			x->GetDoorsSize();
		};
	};

	printSharedPTR(cars);

	//8. Delete the memory allocated for cars once the function returns.
	cout << "\n 8. Delete memory allocated for dynamically allocated cars\n\n";

	auto deleteSharedPTR = [](vector<Car*>& a) -> void
	{
#ifdef debugON
		cout << "In deleteSharedPTR\n";
#endif

		int y = 1;
		for (auto &x : a)
		{
			cout << "\n######################### " << y++ << "\n\n";
			delete x;
			cout << "\n";
		};
	};
	// delete car3;
	deleteSharedPTR(cars);

	cout << "\n Scope End Destructors\n\n";
	_getch();
	return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
