#include "DoorsLarge.h"

DoorsLarge::DoorsLarge() {
#ifdef debugON
	cout << "In constructor DoorsLarge\n";
#endif
}

void DoorsLarge::SetDoorsLarge(int n) {
	count = n;
	size = "Large";

#ifdef debugON
	cout << "In SetDoorsLarge\n";
#endif
}

int DoorsLarge::GetDoorCount() {

#ifdef debugON
	cout << "In  GetDoorCount DoorsLarge\n";
#endif

	return count;
}

string DoorsLarge::GetDoorSize() {
#ifdef debugON
	cout << "In GetDoorSize DoorsLarge\n";
#endif

	return size;
}

DoorsLarge::~DoorsLarge() {
#ifdef debugON
	cout << "In Destructor DoorsLarge\n";
#endif
}