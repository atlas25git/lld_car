#pragma once
#include "Doors.h"
#include<string.h>
using namespace std;

Doors::Doors(){
		
		count = 0;
		size = "";

#ifdef debugON
	cout << "In constructor Doors\n";
#endif
};

Doors::Doors(int x) {

	count = x;

#ifdef debugON
	cout << "In constructor Doors Parameterized\n";
#endif

}

Doors::~Doors(){

#ifdef debugON
	cout << "In Destructor Doors\n";
#endif
}