#include "Nano.h"

Nano::Nano() {
#ifdef debugON
	cout << "In constructor Nano\n";
#endif
	Type = "Nano";
	DL.SetDoorsLarge(0);
	DS.SetDoorsSmall(4);
}

void Nano::GetDoorsCount() {
#ifdef debugON
	cout << "In GetDoorsCount Nano\n";
#endif
	int total = DL.GetDoorCount() + DS.GetDoorCount();
	cout << "Doors in car: " << Type << " are = " << total << "\n";
}

void Nano::GetDoorsSize() {
#ifdef debugON
	cout << "In GetDoorsSize Nano\n";
#endif
	if (DL.GetDoorCount())
		cout << "Door Size is Large\n";
	else if (DS.GetDoorCount())
		cout << "Door Size is Small\n";
}

Nano::~Nano() {
#ifdef debugON
	cout << "In destructor Nano\n";
#endif
}