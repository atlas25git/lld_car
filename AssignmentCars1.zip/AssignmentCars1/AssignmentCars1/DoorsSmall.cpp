#include "DoorsSmall.h"

DoorsSmall::DoorsSmall() {
#ifdef debugON
	cout << "In constructor DoorsSmall\n";
#endif
}

void DoorsSmall::SetDoorsSmall(int n) {
	count = n;
	size = "Small";

#ifdef debugON
	cout << "In SetDoorsSmall\n";
#endif
}

int DoorsSmall::GetDoorCount() {

#ifdef debugON
	cout << "In  GetDoorCount DoorsSmall\n";
#endif

	return count;
}

string DoorsSmall::GetDoorSize() {
#ifdef debugON
	cout << "In GetDoorSize DoorsSmall\n";
#endif

	return size;
}

DoorsSmall::~DoorsSmall() {
#ifdef debugON
	cout << "In Destructor DoorsSmall\n";
#endif
}