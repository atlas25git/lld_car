#include "Swift.h"

Swift::Swift() {
#ifdef debugON
	cout << "In constructor Swift\n";
#endif
	Type = "Swift";
	DL.SetDoorsLarge(4);
	DS.SetDoorsSmall(0);
}

void Swift::GetDoorsCount() {
#ifdef debugON
	cout << "In GetDoorsCount Swift\n";
#endif
	int total = DL.GetDoorCount() + DS.GetDoorCount();
	cout << "Doors in car: " << Type << " are = " << total << "\n";
}

void Swift::GetDoorsSize() {
#ifdef debugON
	cout << "In GetDoorsSize Swift\n";
#endif
	if (DL.GetDoorCount())
		cout << "Door Size is Large\n";
	else if (DS.GetDoorCount())
		cout << "Door Size is Small\n";
}

Swift::~Swift() {
#ifdef debugON
	cout << "In destructor Swift\n";
#endif
}