#pragma once
#include "Car.h"

class Tron : public Car
{
public:
	Tron();

	void GetDoorsCount();

	void GetDoorsSize();

	~Tron();

};