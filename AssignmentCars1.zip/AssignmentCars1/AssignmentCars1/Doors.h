#pragma once
#include<iostream>
#include "Debug.h"
using namespace std;

class Doors
{
protected:
	int count;
	string size;
public:
	Doors();
	Doors(int x);
	virtual ~Doors();
};