#pragma once
#include "Doors.h"

class DoorsSmall : protected Doors
{
public:

	DoorsSmall();

	void SetDoorsSmall(int n);
	int GetDoorCount();
	string GetDoorSize();

	~DoorsSmall();

};