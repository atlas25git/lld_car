#pragma once
#include "Car.h"

class Nano : public Car
{
public:
	Nano();

	void GetDoorsCount();

	void GetDoorsSize();

	~Nano();

};