#include "Tron.h"

Tron::Tron() {
#ifdef debugON
	cout << "In constructor Tron\n";
#endif
	Type = "Tron";
	DL.SetDoorsLarge(0);
	DS.SetDoorsSmall(2);
}

void Tron::GetDoorsCount() {
#ifdef debugON
	cout << "In GetDoorsCount Tron\n";
#endif
	int total = DL.GetDoorCount() + DS.GetDoorCount();
	cout << "Doors in car: " << Type << " are = " << total << "\n";
}

void Tron::GetDoorsSize() {
#ifdef debugON
	cout << "In GetDoorsSize Tron\n";
#endif
	if (DL.GetDoorCount())
		cout << "Door Size is Large\n";
	else if (DS.GetDoorCount())
		cout << "Door Size is Small\n";
}

Tron::~Tron() {
#ifdef debugON
	cout << "In destructor Tron\n";
#endif
}