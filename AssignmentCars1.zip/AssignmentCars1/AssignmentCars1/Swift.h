#pragma once
#include "Car.h"

class Swift : public Car
{
public:
	Swift();

	void GetDoorsCount();

	void GetDoorsSize();

	~Swift();

};
